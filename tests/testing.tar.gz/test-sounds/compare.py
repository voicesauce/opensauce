from __future__ import division
import re
import pprint
import math
pp = pprint.PrettyPrinter()

def read_in_csv(filename):
	dlines = []
	with open(filename, 'rb') as f:
		for line in f:
			dlines.append(line.split(','))
	return dlines

def make_dict(somelist):
	headers = somelist[0]
	s1 = somelist[1]
	s2 = somelist[2]
	s3 = somelist[3]
	data = {}
	for i in range(len(headers)):
		data[headers[i]] = ''
	for i in range(len(headers)):
		val = (s1[i], s2[i], s3[i])
		if any(v for v in val if v != "0"):
			data[headers[i]] = val
		else:
			data[headers[i]] = "NA"
	return data



f0algs = {
	'straight': re.compile(r'strF0_mean(?P<s>[s])?(?P<seg>\d\d\d)?'),
	'snack': re.compile(r'sF0_mean(?P<s>[s])?(?P<seg>\d\d\d)?'),
	'praat': re.compile(r'pF0_mean(?P<s>[s])?(?P<seg>\d\d\d)?'),
	'shr': re.compile(r'shrF0_mean(?P<s>[s])?(?P<seg>\d\d\d)?')
}

formant_algs = {
	'snack': re.compile(r'sF[1-9]_mean(?P<s>[s])?(?P<seg>\d\d\d)?'),
	'praat': re.compile(r'pF[1-9]_mean(?P<s>[s])?(?P<seg>\d\d\d)?')
}

hxhx = {
	"H1H2c": re.compile(r'H1H2c_mean(?P<s>[s])?(?P<seg>\d\d\d)?'),
	"H1H2u": re.compile(r'H1H2u_mean(?P<s>[s])?(?P<seg>\d\d\d)?'),
	"H2H4c": re.compile(r'H2H4c_mean(?P<s>[s])?(?P<seg>\d\d\d)?'),
	"H2H4u": re.compile(r'H2H4u_mean(?P<s>[s])?(?P<seg>\d\d\d)?')
}

hxax = {
	"H1A1": re.compile(r'H1A1u_mean(?P<s>[s])?(?P<seg>\d\d\d)?'),
	"H1A2": re.compile(r'H1A\d(?P<norm>[c|u])_mean(?P<s>[s])?(?P<seg>\d\d\d)?'),
	"H1A3": re.compile(r'H1A\d(?P<norm>[c|u])_mean(?P<s>[s])?(?P<seg>\d\d\d)?')
}

fields = {
	"F0": f0algs,
	"formants": formant_algs,
	"HxHx": hxhx,
	"HxAx": hxax
}


def clean_dict(dirtydict, field=None):
	rexes = fields[field]
	clean_dict = {}
	for k in dirtydict:
		for r in rexes:
			m = re.match(rexes[r], k)
			if m:
				if m.group('s') == 's':
					x = m.string[:m.start('s')] + m.string[m.start('s')+1:]
					clean_dict[x] = dirtydict[k]
				else:
					clean_dict[k] = dirtydict[k]
	return clean_dict
				
def get_data(dict1, dict2, field=None):
	alg = fields[field]
	dict1 = clean_dict(dict1, field = field)
	dict2 = clean_dict(dict2, field = field)
	data = {}
	keystr = field + '_mean'
	keyset = set(dict1.keys() + dict2.keys())
	for k in keyset:
		vals = ["NA", "NA"]
		if k in dict1.keys():
			#print k, dict1[k]
			vals[0] = dict1[k]
		if k in dict2.keys():
			#print k, dict2[k]
			vals[1] = dict2[k]
		data[k] = vals
	return data


def get_diffs(data):
	diffs = {}
	for k in data.keys():
		assert len(data[k]) == 2, "Comparison must be between exactly 2 tuples of data."
		d1 = data[k][0]
		d2 = data[k][1]
		f = lambda l: any(v for v in l if re.match(r'^N', v))
		if f(d1) or f(d2):
			for i in range(len(d1)):
				if d1 == d2:
					continue
				diffs[k] = '0: '+str(d1) + ' , 1:'+str(d2)
				#diffs[k] = 'NA'
			continue
		d1 = [float(v) for v in data[k][0]]
		d2 = [float(v) for v in data[k][1]]
		f = lambda x: d1[x] - d2[x]
		for i in range(len(d1)):
			if f(i) != 0.:
				diffs[k] = '0: '+str(d1[i]) + ' , 1:'+str(d2[i]) + ', diff = ', str(d1[i] - d2[i])
	return diffs

def compare(file1, file2, by=None):
	compstr = "[ 0: " + file1 + " ] , [ " + file2 + " ]"	
	d1 = make_dict(read_in_csv(file1))
	d2 = make_dict(read_in_csv(file2))
	if by in fields:
		algs = fields[by]
	else:
		return
	comparison = {x: get_diffs(get_data(d1, d2, field = by)) for x in algs.keys()}
	pp.pprint( (compstr, comparison))
	print "\n\n"



hxfile = "HxHx-OCT.csv"
hafile = "HxAx-OCT.csv"

raw = read_in_csv(hxfile)
pp.pprint(raw)

# def do(filenames, by):
# 	fnames = filenames[:]
# 	print fnames
	




# v0 = "v0/f0/f0.csv"
# v1 = "v1/f0/f0.csv"
# voct = "oct/f0/f0.csv"
# files = [v0, v1, voct]
# do(files, by = "F0")





# 	compare(v0, v1, by="F0")
# 	compare(v0, voct, by="F0")

# def formants():
# 	v0 = "v0/formants/formants.csv"
# 	v1 = "v1/formants/formants.csv"
# 	voct = "oct/formants/formants.csv"
# 	compare(v0, v1, by = "formants")
# 	compare(v0, voct, by = "formants")
# 	compare(v1, voct, by = "formants")

# def do_hxhx():
# 	v0 = "v0/harmonics/HxHx.csv"
# 	v1 = "v1/harmonics/HxHx.csv"
# 	voct = "oct/harmonics/HxHx.csv"
# 	compare(v0, v1, by = "HxHx")
# 	compare(v1, voct, by = "HxHx")


# def do_hxax():
# 	v0 = "v0/harmonics/HxAx.csv"
# 	v1 = "v1/harmonics/HxAx.csv"
# 	voct = "oct/harmonics/HxAx.csv"
# 	compare(v0, v1, by = "HxAx")


# f0()

# v0 = "v0/harmonics/HxAx.csv"
# v1 = "v1/harmonics/HxAx.csv"
# voct = "oct/harmonics/HxAx.csv"

# d1 = make_dict(read_in_csv(v0))
# d2 = make_dict(read_in_csv(v1))
# doct = make_dict(read_in_csv(voct))
# d = get_diffs(get_data(d1, d2, field="HxAx"))
# pp.pprint(d)
# pp.pprint(get_diffs(get_data(d1, doct, field="HxAx")))



